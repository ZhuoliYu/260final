import './App.css';
// import {BrowserRouter as Router,Routes,Route} from'react-router-dom';
import MainPage from './pages/main';


function App() {
  return (
    // <Router>
    //   <Routes>
    //     <Route path="/" element={<MainPage />} />
    //     <Route path="/my-watch-list" element={<MyWatchList />} />
    //   </Routes>
    // </Router>
    <MainPage />

  );
}

export default App;
